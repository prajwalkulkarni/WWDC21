//
//  AnswerDelegate.swift
//  Book_Sources
//
//  Created by Prajwal Kulkarni on 11/04/21.
//


import UIKit


//Protocol
protocol AnswerDelegate: class {
    
    func answerPressed(btnIndex :Int,sender: UIButton)
    
}

